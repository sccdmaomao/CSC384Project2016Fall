"""
SampleRun.py contains test scripts based on Othello game.
It will create 2 AIs that play against each other using different strategy and algorithms.
To show the efficiency of algorithm results
"""

from Othello import *
from Engine import *

init_game = Othello()
init_game.initialize_board()

player_1 =
player_2 =
